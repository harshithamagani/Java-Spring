package com.coding.dojo.repositories;

import org.springframework.data.repository.CrudRepository;

import com.coding.dojo.models.Like;

public interface LikeRepository extends CrudRepository<Like, Long>{

}
